<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>testing</label>
    <protected>false</protected>
    <values>
        <field>Case_Origin__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Case_Priority__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Case_Record_Type__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Keyword__c</field>
        <value xsi:type="xsd:string">issue, damage, missing, tv, television, toasters, toaster, Toasters, Toaster, support, refund</value>
    </values>
    <values>
        <field>Routing_Queue_Name__c</field>
        <value xsi:type="xsd:string">Case Routing Demo</value>
    </values>
    <values>
        <field>Support_Email__c</field>
        <value xsi:type="xsd:string">testingforwarding05@gmail.com</value>
    </values>
</CustomMetadata>
